# **ASSIGNMENT 4**
# Question 1
### The user defined datatypes used in this code are:
--- 
#### 1. Account_Type
```
typedef enum Account_Type{
    savings,
    current
}Account_Type;
```
- it is enum datatype

- it has members savings and current 

#### 2. AccountInfo

``````
typedef struct AccountInfo{
    int Account_number;
    Account_Type type;
    char name[51];
    float balance;
}AccountInfo;
``````
- it is a structure required for details of account holder

#### 3. node

``````
typedef struct node{
    AccountInfo data;
    struct node* next;
}node;
``````
- it is structure for required for node of a linkedlist
#### 4. LinkedList
``````
typedef node* LinkedList;
``````
- it is a pointer of node datatype

---
### The functions written in this code are:
---
### 1. createAccount
``````
LinkedList createAccount(Account_Type  ,char*  ,float )
``````
- it takes the parameters Account type , Name, Amount
- command :  **CREATE  Accounttype  Name Amount**
- it's return type is a LinkedList
- it creates a new bank account such that its account number is the least possible availiable account number 
- if the current existing account numbers are not in sequence (100,101,102,103....) then , it inserts the newly created account at the missing account number spot .if 100 was not present in the current list then it appends the new account in the begining and modifies the head pointer
- if they were already in sequence then it appends the newly created bank account at the end
- if an account of the same account type and name exists is prints:

       Invalid: User already exists!
-   Otherwise, it creates a new bank account to the  linkedlist of babk accounts.
- whenever a new bank account is created it prints its details in the following format:

        Account Number: int
        Account Holder: name
        Account Type: savings/current
        Balance: Rs. float

-  balance is represented in float datatype upto 2 decimal places

- it returns the head of the linlkedlist 
### 2. deleteAccount
    LinkedList deleteAccount(Account_Type ,char* )
- it takes the parameters Account type and name
- command : **DELETE Accounttype    name**
- it's return type is linked list
- this function deletes the account which matches with the input details
- it returns the head of the modified linkedlist 
- whenever an account is deleted it prints:

        Account deleted successfully
- if an account of the given details was not found then it prints:

      Invalid: User does not exist
### 3. lowBalanceAccounts
    LinkedList lowBalanceAccounts(LinkedList )
- it takes list of bank accounts as a linkedlist as its parameter
- it's return type is also a linkedlist
- it returns the head of the linkedlist
- it does not modifies the linked list
- it just traverses the linkedlist and prints the account number ,name and balance of all the accounts with a balance less than 100 in the following format:

      Account Number: number, Name: name, Balance: float
- balance is represented in float datatype upto 2 decimal places
- if no such account is found or the list is empty then it prints:

      No accounts found with low balance

### 4. transaction
    LinkedList transaction(int ,float ,int )
- it takes the parameters account.no ,amount ,code(0 for withdrawl,1 for deposit)
- command : **TRANSACTION  account.no amount code**
- if an account with inputted account.no exists then it performs the specified operation 
- if operation is possible then it updates the account balance and prints:
 
       Updated balance is Rs. float
       
- balance is represented in float datatype upto 2 decimal spaces
- if operation is not possible it prints:

      The balance is insufficient for the specified withdrawal
- if no such account is found or the linkedlist is empty it prints:

      Invalid: User does not exist
- its return type is a linkedlist 
- it returns the head of the linkedlist 
### 5. display
        void display(LinkedList )
- it takes the linked list as the parameter
- command : **DISPLAY**
- its return type is void
- it prints details of all the bank accounts which are currently in the linkedlist in the following format:

      Account Number	Account Type	Name		Balance
      -------------------------------------------------------


- if the list is empty then it prints:

      No Accounts to display

---
 - the code is terminated when the command : **EXIT** is given.

 # Question 2
 ### The user defined datatypes int this code are:
 ---
 #### 1. node
         typedef struct node{
         float data;
         struct node* next;
         }node;
- it is structure required to create a linkedlist
#### 2. Linkedlist
     typedef node* Linkedlist; 
- linkedlist is pointer to the node
---
### The functions written in this code are:

---
### 1. append

    Linkedlist append(float , Linkedlist )
- it takes the parameters float value and a linkedlist

- this functions appends the passed float vlaue elements to the corresponding passed linkedlist
- it returns the linkedlist(the complex number magnitude ).
after appending the element
### 2. add

     Linkedlist add(Linkedlist ,Linkedlist )
- command : **ADD n**
- it takes two linkedlist(i.e, the complex numbers magnitude ) as its parameters 
- it adds the correspondings elements of the two linked list and appends it to a new linkedlist(result linkedlist)

- it returns the head of the new linkedlist.
### 3. sub
     Linkedlist sub(Linkedlist ,Linkedlist )
-  command : **SUB n**
- it takes two linkedlist(i.e, the complex numbers magnitude ) as its parameters 
- it subtracts  the correspondings elements of the two linked list and appends it to a new linkedlist(result linkedlist)
### 4. dot
    float dot(Linkedlist ,Linkedlist )
- command : **DOT n**
- it takes two linkedlist(i.e, the complex numbers magnitude ) as its parameters 
- it calculates the dot product of the two given lists by summing the product of corresponding elements of the linkedlist
- it returns a float value which is the dot product of the two passed linkedlist
### 5. mod
     float mod(Linkedlist )
- it takes a linkedlist(complex numbers magnitude ) as its parameter and calulates its mod value
- it calulates the summation of squares of  data elements of the linkedlist
- it returns the squareroot of the calculated value which is a float value
### 6. cosineSimilarity

    float cosineSimilarity(Linkedlist ,Linkedlist )
- it takes two linkedlist(input complex number magnitudes) as its parameter
- it calulates the dot product of the two linkedlist using the  **dot** function
- it calutaed the mod of each linkedlist using the **mod** function
- it returns a float value
### 7. print_list
    void print_list(Linkedlist )  
- it takes the linkedlist(result linkedlist) as its parameter and prints the data elements of the linkedlist upto to 2 decimal places
---
- the result is empty if n is 0.
- the code is terminated when a  **-1** intput is given .
---

# Question 3
 ### The user defined datatypes int this code are:
 ---
 #### 1. node
        typedef struct node{
            int data;
            struct node* next;
        }node;

- it is structure required to create a linkedlist
#### 2. Linkedlist
    typedef node* Linkedlist;
- it is a pointer to the node

---
### The functions written in this code are:

---
### 1. append

    Linkedlist append(int , Linkedlist )
- it takes the parameters int value and a linkedlist

- this functions appends the passed int vlaue elements to the corresponding passed linkedlist
- it returns the linkedlist(head)
after appending the element
### 2. removeDuplicates
    Linkedlist removeDuplicates(Linkedlist )
- it takes the above created linkedlist as its parameter
- it then traverses the linkedlist starting from its head
- it deletes an element from the linkedlist(modification of linkedlist) if its data is same as that of  previous node and then it stores that previous node for its comparision with the data of next to it in the modified linkedlist
- it returns the modified linkedlist

### 3. print_list


    void print_list(Linkedlist )  
- it takes the linkedlist(result linkedlist) as its parameter and prints the data elements of the linkedlist with a **->** sign between any two values.
---
- if n is 0, it prints: 
  
         No colors in the list
--- 

