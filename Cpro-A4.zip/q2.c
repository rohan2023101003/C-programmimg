#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
typedef struct node{
    float data;
    struct node* next;
}node;
typedef node* Linkedlist; 
Linkedlist append(float p, Linkedlist list) {
    Linkedlist head =list;
    node* D = (node *) malloc(sizeof(node));
    D->data = p;
    D->next = NULL;
    if (list == NULL) return D;
    while (list->next != NULL) {
        list = list->next;
    }
    list->next = D;
    list = head;
    return list;
}
void print_list(Linkedlist list) {
    while (list!= NULL) {
        printf("%.2f ",list->data);
        list= list->next;   
    } 
}
Linkedlist add(Linkedlist list1,Linkedlist list2){
    Linkedlist list;
    list=NULL;
    float r;
    while(list1!=NULL){
        r=list1->data+list2->data;
        list1=list1->next;
        list2=list2->next;
        list=append(r,list);
    }
    return list;
}
Linkedlist sub(Linkedlist list1,Linkedlist list2){
    Linkedlist list;
    list =NULL;
    float r;
    while(list1!=NULL){
        r=list1->data-list2->data;
        list1=list1->next;
        list2=list2->next;
        list=append(r,list);
    }
    return list;
}
float dot(Linkedlist list1,Linkedlist list2){
    Linkedlist list;
    float sum=0;
    list =NULL;
    float r;
    while(list1!=NULL){
        r=(list1->data)*(list2->data);
        list1=list1->next;
        list2=list2->next;
       sum=sum+r;
    }
    return sum;
}
float mod(Linkedlist l){
    float mod=0;
    while(l!=NULL){
        mod=mod+ (l->data)*(l->data);
        l=l->next;
    }
    return sqrt(mod);
}
float cosineSimilarity(Linkedlist list1,Linkedlist list2){
    float numerator=dot(list1,list2);
    float denominator=mod(list1)*mod(list2);
    return numerator/denominator;
}
int main(){
    char s[9];
    scanf("%s",s);
    while(strcmp(s,"-1")!=0){
    int n;
    scanf("%d",&n);
    int w=n;
    Linkedlist list1,list2,list3;
    list1=NULL;
    list2=NULL;
    list3=NULL;
    while(n--){
        float d;
        scanf("%f",&d);
        list1=append(d,list1);
    }
    while(w--){
        float h;
        scanf("%f",&h);
        list2=append(h,list2);

    }
    if(strcmp(s,"ADD")==0){
         list3= add(list1,list2);
         printf("Result: ");
         print_list(list3);
         printf("\n");

    }
    if(strcmp(s,"SUB")==0){
         list3=sub(list1,list2);
         printf("Result: ");
         print_list(list3);
         printf("\n");
    }
    if(strcmp(s,"DOT")==0){
        float val=dot(list1,list2);
        printf("Result: ");
        printf("%.2f\n",val);
        
    }
    if(strcmp(s,"COSINE")==0){
         float cos=cosineSimilarity(list1,list2);
         printf("Result: ");
         printf("%.2f\n",cos);

    }
    char str[9];
    scanf("%s",str);
    strcpy(s,str);
    }
}