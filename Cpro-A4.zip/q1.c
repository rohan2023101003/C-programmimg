#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef enum Account_Type{
    savings,
    current
}Account_Type;
char str[2][20]={"savings","current"};
typedef struct AccountInfo{
    int Account_number;
    Account_Type type;
    char name[51];
    float balance;
}AccountInfo;
typedef struct node{
    AccountInfo data;
    struct node* next;
}node;
typedef node* LinkedList;
 LinkedList l,
    l=NULL;
void display(LinkedList l){
    LinkedList list;
    list=l;
    if(l==NULL){
        printf("No Accounts to display\n");
    }
    else{
    printf("\nAccount Number\tAccount Type\tName\t\tBalance\n");
    printf("-------------------------------------------------------\n");
    while (list!= NULL) {
        printf("%d\t\t%s\t\t%s\t\t%.2f\n",list->data.Account_number,str[list->data.type],list->data.name,list->data.balance);
        list= list->next;  
    } 
    }
}
LinkedList createAccount(Account_Type Type,char* name,float amount){
    LinkedList head,list,dead,check;
    dead=l;
    head=l;
    list=l;
    check=l;
    int flaag=0;
    while(dead!=NULL){
        if(Type==dead->data.type && strcmp(dead->data.name,name)==0){
            flaag=1;
            break;
        }
        dead=dead->next;
    }
    if(flaag==0){
                AccountInfo p;
                p.type=Type;
                strcpy(p.name,name);
                p.balance=amount;
                p.Account_number=100;
                LinkedList head =list;
                node* D = (node *) malloc(sizeof(node));
                D->data = p;
                D->next = NULL;
        
                if (list == NULL){
                        printf("Account Number: %d\n",D->data.Account_number);
                        printf("Account Holder: %s\n",D->data.name);
                        printf("Account Type: %s\n",str[D->data.type]);
                        printf("Balance: Rs. %.2f\n",D->data.balance);
                     return D;
                }
               int i=0;
        if(head->data.Account_number==100){
              while(check!=NULL){
                if(check->data.Account_number==100+i){
                    check=check->next;
                    i++;
                }
                else{
                    break;
                }
              }
              if(check==NULL){
                while (list->next != NULL){
                    list = list->next;
                }
                list->next = D;
                D->data.Account_number=100+i;
                        printf("Account Number: %d\n",D->data.Account_number);
                        printf("Account Holder: %s\n",D->data.name);
                        printf("Account Type: %s\n",str[D->data.type]);
                        printf("Balance: Rs. %.2f\n",D->data.balance);
                list = head;
                return list;
              }
              else{
                int j=1;
                while(j<i){
                    list=list->next;
                    j++;
                }
                D->next=list->next;
                list->next=D;
                D->data.Account_number=100+i;
                        printf("Account Number: %d\n",D->data.Account_number);
                        printf("Account Holder: %s\n",D->data.name);
                        printf("Account Type: %s\n",str[D->data.type]);
                        printf("Balance: Rs. %.2f\n",D->data.balance);
             } 
        } 
        else{
                D->next=head;
                head=D;
                        printf("Account Number: %d\n",D->data.Account_number);
                        printf("Account Holder: %s\n",D->data.name);
                        printf("Account Type: %s\n",str[D->data.type]);
                        printf("Balance: Rs. %.2f\n",D->data.balance);
                return head;

        }                
    }
    else{
        printf("Invalid: User already exists!\n");
    }
    return head;   
}
LinkedList deleteAccount(Account_Type Type,char* name){
   LinkedList head,prev;
   head=l;
   prev=l;
   int flag=0;
   while(l!=NULL){
      if(l->data.type==Type && strcmp(l->data.name,name)==0){
        if(l!=head){
         prev->next=l->next;
         l->next=NULL;
         flag=1;
         break;
        }
        else{
            head=head->next;
            prev->next=NULL;
            flag=1;
            break;
        }
      }
    prev=l;
    l=l->next;
   }
   if(flag==0){
    printf("Invalid: User does not exist\n");
   }
   else{
    printf("Account deleted successfully\n");
   }
   return head;
}
LinkedList lowBalanceAccounts(LinkedList l){
    LinkedList var;
    var=l;
    int z=0;
    int y=0;
    while(var!=NULL){
        if(var->data.balance<100){
            y++;
            printf("Account Number: %d, Name: %s, Balance: %.2f\n",var->data.Account_number,var->data.name,var->data.balance);
        }
        var=var->next;
        z++;
    }
    if(y==0){
        printf("No accounts found with low balance\n");
    }
    return l;
}
LinkedList transaction(int acc_no,float amount,int code){
    LinkedList tem;
    tem=l;
    int ind=0;
    while(tem!=NULL){
         if(tem->data.Account_number==acc_no){
            ind=1;
            break;
         }
         tem=tem->next;
    }
    if(ind==1){
            if(code==0){
                if((tem->data.balance-amount)<100){
                    printf("The balance is insufficient for the specified withdrawal\n");
                }
                else{
                    tem->data.balance=tem->data.balance-amount;
                    printf("Updated balance is Rs. %.2f\n",tem->data.balance);
                }
            }
            else{
            tem->data.balance=tem->data.balance+amount;
            printf("Updated balance is Rs. %.2f\n",tem->data.balance);
            }
    }
    else{
         printf("Invalid: User does not exist\n");
    }
    return l;
}
int main(){
    char in[20];
    scanf("%s",in);
    while(strcmp(in,"EXIT")!=0){  
        if(strcmp(in,"CREATE")==0){
            Account_Type types;
            char stri[15];
            scanf("%s",stri);
            if(strcmp(stri,"savings")==0)
            types=0;
            else types=1;
            char names[51];
            scanf("%s",names);
            float amount;
            scanf("%f",&amount);
            l=createAccount(types,names,amount);
        }
        if(strcmp(in,"DELETE")==0){
            Account_Type type;
            char stri[15];
            scanf("%s",stri);
            if(strcmp(stri,"savings")==0)
            type=0;
            else type=1;
            char name[51];
            scanf("%s",name);
            l= deleteAccount(type,name);
        }
        if(strcmp(in,"LOWBALANCE")==0){
            l=lowBalanceAccounts(l);
        }
        if(strcmp(in,"TRANSACTION")==0){
            int an,cd;
            float am;
            scanf("%d %f %d",&an,&am,&cd);
            l=transaction(an,am,cd);

        }
        if(strcmp(in,"DISPLAY")==0){
            display(l);
        }
        char in1[20];
        scanf("%s",in1);
        strcpy(in,in1);
    }
}