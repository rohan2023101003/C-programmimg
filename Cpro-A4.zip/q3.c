#include<stdio.h>
#include<stdlib.h>
typedef struct node{
    int data;
    struct node* next;
}node;
typedef node* Linkedlist;
Linkedlist append(int p, Linkedlist l) {
    Linkedlist head =l;
    node* D = (node *) malloc(sizeof(node));
    D->data = p;
    D->next = NULL;
    if (l == NULL) return D;
    while (l->next != NULL) {
        l = l->next;
    }
    l->next = D;
    l = head;
    return l;
}
Linkedlist removeDuplicates(Linkedlist l){
    Linkedlist head,prev;
    head=l;
    //modification of the linked list
    while(l->next!=NULL){
    prev=l;
    int a= prev->data;
    l=l->next;
    int b =l->data;
    if(a==b){
        prev->next=l->next;
        l->next=NULL;
        l=prev;
    }
   }
   return head;
}
void print_list(Linkedlist l) {
    while (l!= NULL) {
        printf(" %d ",l->data);
        if(l->next!=NULL){
            printf("->");
        }
        l= l->next;   
    } 
}
int main(){
    int n;
    printf("Enter the number of colors in the list: ");
    scanf("%d",&n);
    if(n>0){
    Linkedlist l;
    l=NULL;
    printf("Enter the colors: ");
    while(n--){
        int d;
        scanf("%d",&d);
        l=append(d,l);
    }
   // print_list(l); //linkedlist before modification
    l=removeDuplicates(l);//returns head of the modified linked list
    printf("Modified Linked list : ");
    print_list(l);//linkedlist after modification
    }
    else{
        printf("No colors in the list\n");
    }
}