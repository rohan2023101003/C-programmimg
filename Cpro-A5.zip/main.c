#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "matrix.h"
int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        char str[50];
        scanf("%s",str);
        if(strcmp(str,"determinant")==0 || strcmp(str,"transpose_matrix")==0 || strcmp(str,"scalar_mult_matrix")==0 || strcmp(str,"mult_matrix")==0 || strcmp(str,"history")==0 || strcmp(str,"add_matrix")==0){
        FILE* fp;
        if(strcmp(str,"history")==0){
            fp= fopen("mx_history","a");
            fprintf(fp,"LOG::%s\n",str);
            fclose(fp);

            fp=fopen("mx_history","r");
            char e=fgetc(fp);
            while (e!=EOF)
            {
                printf("%c",e);
                e=fgetc(fp);
            }
            fclose(fp);
        }
        else{
        int ad;
        scanf("%d",&ad);
         fp=fopen("mx_history","a");
        fprintf(fp,"LOG::%s %d\n",str,ad);
        fclose(fp);
        if(strcmp(str,"add_matrix")==0){
        if(ad==0){
            int n1,m1;
            scanf("%d %d",&n1,&m1);
            Matrix* M1 = scan_matrix(n1,m1);
            int n2,m2;
            scanf("%d %d",&n2,&m2);
            Matrix* M2= scan_matrix(n2,m2);
            Matrix* M3= add_matrix(M1,M2);
            print_matrix(M3);
            destroy_matrix(M1);
            destroy_matrix(M2);
            if(M3==NULL) free(M3);
            else destroy_matrix(M3);
        }
        if(ad==1){
            char file1[150];
            scanf("%s",file1);
            char file2[150];
            scanf("%s",file2);
            char file3[150];
            scanf("%s",file3);
            Matrix* M1= read_matrix_from_file(file1);
            if(M1==NULL){
                free(M1);
                continue;
            }
            Matrix* M2= read_matrix_from_file(file2);
            if(M2==NULL){
                free(M2);
                continue;
            }
            Matrix* M3= add_matrix(M1,M2);
            if(M3==NULL){
                free(M3);
                printf("ERROR: INVALID ARGUMENT\n");
                continue;
            }
            write_matrix_to_file(file3,M3);
            destroy_matrix(M1);
            destroy_matrix(M2);
            destroy_matrix(M3);
        }
    }
    if(strcmp(str,"mult_matrix")==0){
        if(ad==0){
            int n1,m1;
            scanf("%d %d",&n1,&m1);
            Matrix* M1 = scan_matrix(n1,m1);
            int n2,m2;
            scanf("%d %d",&n2,&m2);
            Matrix* M2= scan_matrix(n2,m2);
            Matrix* M3= mult_matrix(M1,M2);
            print_matrix(M3);
            destroy_matrix(M1);
            destroy_matrix(M2);
            if(M3==NULL) free(M3);
            else destroy_matrix(M3);
        }
        if(ad==1){
            char file1[150];
            scanf("%s",file1);
            char file2[150];
            scanf("%s",file2);
            char file3[150];
            scanf("%s",file3);
            Matrix* M1= read_matrix_from_file(file1);
            if(M1==NULL){
                free(M1);
                continue;
            }
            Matrix* M2= read_matrix_from_file(file2);
            if(M2==NULL){
                free(M2);
                continue;
            }
            Matrix* M3=mult_matrix(M1,M2);
            if(M3==NULL){
                free(M3);
                 printf("ERROR: INVALID ARGUMENT\n");
                continue;
            }
            write_matrix_to_file(file3,M3);
            destroy_matrix(M1);
            destroy_matrix(M2);
            destroy_matrix(M3);
           
        }
    }
    if(strcmp(str,"scalar_mult_matrix")==0){
      if(ad==0){
            long long int s;
            scanf("%lld",&s);
            int n,m;
            scanf("%d %d",&n,&m);
            Matrix* M =scan_matrix(n,m);
            Matrix* M3= scalar_mult_matrix(s,M);
            print_matrix(M3);
            destroy_matrix(M);
            destroy_matrix(M3);
      }
      if(ad==1){
            long long int s;
            scanf("%lld",&s);
            char file1[150];
            scanf("%s",file1);
             char file2[150];
            scanf("%s",file2);
            Matrix* M1= read_matrix_from_file(file1);
            if(M1==NULL){
                free(M1);
                continue;
            }
            Matrix* M2= scalar_mult_matrix(s,M1);
            write_matrix_to_file(file2,M2);
            destroy_matrix(M1);
            destroy_matrix(M2);
      }
   }
   if(strcmp(str,"transpose_matrix")==0){
        if(ad==0){
            int n,m;
            scanf("%d %d",&n,&m);
            Matrix* M = scan_matrix(n,m);
            Matrix* M3= transpose_matrix(M);
            print_matrix(M3);
            destroy_matrix(M);
            destroy_matrix(M3);
        }
        if(ad==1){
                char file1[150];
                scanf("%s",file1);
                char file2[150];
                scanf("%s",file2);
                Matrix* M1= read_matrix_from_file(file1);
                if(M1==NULL){
                  free(M1);
                  continue;
                }
                Matrix* M2= transpose_matrix(M1);
                write_matrix_to_file(file2,M2); 
                destroy_matrix(M1);
                destroy_matrix(M2);
        } 
    }
    if(strcmp(str,"determinant")==0){
      if(ad==0){
            int n,m;
            scanf("%d %d",&n,&m);
            Matrix* M = scan_matrix(n,m);
            if(n==m){
            long long int det= determinant(M);
            printf("%lld\n",det);
            }
            else{
             printf("ERROR: INVALID ARGUMENT\n");   
            }
             destroy_matrix(M);
        }
       if(ad==1){
            char file1[150];
            scanf("%s",file1);
            Matrix* M1= read_matrix_from_file(file1);
            if(M1==NULL){
                  free(M1);
                  continue;
            }
            int n= M1->num_rows;
            int m=M1->num_cols;
             if(n==m){
                long long int det= determinant(M1);
                printf("%lld\n",det);
            }
            else{
              printf("ERROR: INVALID ARGUMENT\n");   
            }
             destroy_matrix(M1);
       }
    }
    }
    }
    else{
        printf("ERROR\n");
    }
    }
  return 0;
} 