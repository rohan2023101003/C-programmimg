#include<stdio.h>
void main(){
    int n,i,j,c,k,l=0,r,m=0,y=0;
    scanf("%d",&n);
    int a[n+1];
    a[0]=0;
    for(i=1;i<(n+1);i++){
        scanf("%d",&a[i]);
    }
    for(i=1;i<=n;i++){
        for(j=i;j<=n;j++){
            int b[j];
            c=0;
            for(k=i;k<(j+1);k++){
                b[c]=a[k];
                c++;
            }
             l=0;
             m=0;
             r=c-1;
              if(c==1){
              m=0;
              }
             else{
             while(r>l){
             if(b[l]==b[r]){
                m++;
            }
            else{
                m=-1;
                break;
            }
            l++;
            r--;
           } 
           }   
           if(m==(c/2)){
            y++;
          }

        }
    }
    printf("%d",y);
}
