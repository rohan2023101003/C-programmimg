#include<stdio.h>
void main(){
    int n,i,j;
    scanf("%d",&n);
    int a[n][n];
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            scanf("%d",&a[i][j]);
        }
    }
    int D;
    scanf("%d",&D);
    int temp1=a[0][0];
    int temp2=a[n-1][n-1];
    int temp3=a[n-1][0];
    int temp4=a[0][n-1];
    if(D==0){
    for(j=0;j<(n-1);j++){
        a[0][j]=a[0][j+1];
    }
    for(j=(n-1);j>0;j--){
        a[n-1][j]=a[n-1][j-1];
    }
    for(i=(n-1);i>0;i--){
        a[i][0]=a[i-1][0];
    }
    for(i=0;i<(n-1);i++){
        a[i][n-1]=a[i+1][n-1];
    }
    a[1][0]=temp1;
    a[n-2][n-1]=temp2;
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            printf("%d ",a[i][j]);
    }
    printf("\n");
    }
    }
    if(D==1){
    for(j=(n-1);j>0;j--){
        a[0][j]=a[0][j-1];
    }
    for(j=0;j<(n-1);j++){
        a[n-1][j]=a[n-1][j+1];
    }
    for(i=0;i<(n-1);i++){
        a[i][0]=a[i+1][0];
    }
    for(i=(n-1);i>0;i--){
        a[i][n-1]=a[i-1][n-1];
    }
    a[n-2][0]=temp3;
    a[1][n-1]=temp4;
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            printf("%d ",a[i][j]);
    }
    printf("\n");
    }
    }
}
