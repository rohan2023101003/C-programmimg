#include<stdio.h>
int main(){
    int n,p,i=1;
    scanf("%d",&n);
    if(n==0){
        printf("0");
    }
    else{
    while(n!=0){
        if(n%2==0){
            n=n/2;
            printf("0");
        }
        else{
            n=n-1;
            //i++;
            n=n/2;
            printf("1");
        }
    }
    }
    return 0;
}