#include<Stdio.h>
int main(){
    int n,p;
    scanf("%d",&n);
    int j=0,i=1;
    for(i=1;i*i<=n;i++){
        printf("%d ",i*i);
    }
    return 0;
}
//only those doors will be open which are appearing odd no.of times i.e,all the perfect scores