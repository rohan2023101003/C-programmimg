#include<Stdio.h>
void main(){
    int n,i,j,k,sum=0;
    scanf("%d",&n);
    int a[n][4];
    int b[100][100]={0};
   /* for(i=0;i<100;i++){
        for(j=0;j<100;j++){
            b[i][j]=0;
        }
    }*/
    for(i=0;i<n;i++){
        for(j=0;j<4;j++){
            scanf("%d",&a[i][j]);
        }
    }
    for(k=0;k<n;k++){
        for(i=a[k][0];i<a[k][1];i++){
            for(j=a[k][2];j<a[k][3];j++){
                b[i][j]=1;
            }
        }
    }
    for(i=0;i<100;i++){
        for(j=0;j<100;j++){
            sum=sum+b[i][j];
        }
    }
    printf("%d",sum);
}