#include<stdio.h>
#include<math.h>
int main(){
    int n,m,k;
    scanf("%d %d %d",&n,&m,&k);
    int f=1000000007;
    int arr[n+1][m+1];
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            arr[i][j]=0;
        }
    }
    for(int p=1;p<=k;p++){
        int i,j;
        scanf("%d %d",&i,&j);
        arr[i][j]=-1;
    }
    for(int j=1;j<=m;j++){
        arr[1][j]=1;
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            if(arr[i][j]>=1){
                for(int k=1;k<=4;k++){
                    int x,y;
                    if(k==1){
                     x=i+1;
                     y= j+2;
                    }
                    if(k==2){
                     x=i+1;
                     y= j-2;
                    }
                    if(k==3){
                     x=i+2;
                     y= j+1;
                    }
                    if(k==4){
                     x=i+2;
                     y= j-1;
                    }
                    if(x>0 && y>0 && x<=n && y<=m){
                        if(arr[x][y]!=-1){
                            arr[x][y]=(arr[x][y]+arr[i][j])%f;
                        }
                    }
                }
            }
        }
    }
    int z=n;
    for(int j=1;j<=m;j++){
        int r=arr[z][j];
        printf("%d ",r%f);
    }
    printf("\n");

    return 0;
}