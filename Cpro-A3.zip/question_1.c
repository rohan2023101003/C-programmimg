#include<stdio.h>
#include<string.h>
int main(){
    int upper_count=0;
    int lower_count=0;
    int unique_count=0;
    int distinct_count=0;
    int final=0;
    char str[100];

    scanf("%s",str);
    int n=strlen(str);
    for(int i=0;i<n;i++){
        int a=str[i];
        int arr1[26]={65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90};
        for(int j=0;j<26;j++){
        if(a==arr1[j]){
            upper_count=1;
         //checks for atleast one uppercase letter  

        }
        }
        char arr2[26]="qwertyuioplkjhgfdsazxcvbnm";
        for(int k=0;k<26;k++){

        
        if(str[i]==arr2[k]){
            lower_count=1;
           //checks for atleast one lowercase letter

        }
        }
    }
    for(int j=0;j<n;j++){
        for(int k=0;k<j;k++){
            if(str[k]!=str[j]){
                unique_count++;
            //checks the uniqueness of the letter with its previous letters
            }
        }
        if(unique_count==j){
            distinct_count++;
        }
        unique_count=0;
    }
    if(distinct_count==n){
        final=1;
        //checks for uniqueness of complete string
    }
    if(final==lower_count && final==upper_count){
        //checks for a beautiful string
        printf("Yes\n");

    }
    else{
        printf("No\n");
    }
    return 0;
}
