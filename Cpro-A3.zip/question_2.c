#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char s[40320][9];
int c=0;
int sort (const void *a, const void * b){
    return ( *(char *)a - *(char *)b );//qsort
}
int fact(int n){
    int factorial=1;
    if(n==0){
        factorial= 1;
    }
    else{
    for(int i=1;i<=n;i++){
        factorial =factorial*i;
    }
    }
    return factorial; 
}
int no_of_permutations(char str[],int n,int r){
    for(int i=0;i<n;i++){
        int c=1,m=0;
        for(int k=i-1;k>=0;k--){
            if(str[i]!=str[k]){
                m++;
            }
        }
        if(m==i){
            for(int j=i+1;j<n;j++){
                if(str[i]==str[j]){
                    c++;
                }
            }
        }
        int k= fact(c);
        r=r/k;
    }
   return r;
}
void swap(char *m, char *n){
   int a= *m;
   int b= *n;
   a = a^b;
   b = a^b;
   a = a^b;
   char c,d;
   *m= a;
   *n =b;
}
void quickSort(char* str,int a,int b){
   if(a<b){
    for(int i=a;i<=b;i++){
        for(int j=i;j<=b;j++){
            if(str[i]>str[j]){
                swap((str+i),(str+j));
            }
        }
    }
  }
}
void permute(char *a, int l, int r){ 
    int i; 
    if (l == r) 
        printf("%s\n", a); 
    else{
        for (i = l; i <= r; i++) {
            if(*(a+l)!=*(a+i) || i==l){
            swap((a + l), (a + i)); 
            quickSort(a,l+1,r);
            permute(a, l + 1, r);
            quickSort(a,l+1,r);
            swap((a + l), (a + i)); 
            quickSort(a,l+1,r);
            }
        } 
    } 
} 
void permute_string(char *a, int i, int n){
   int j;
   if (i == n){
    // storing all possible unique strings in an array
       strcpy(s[c],a);
       c++;
    }
   else{
       j=i;
       while(j<=n){
        if(*(a+i)!=*(a+j) || i==j){
         swap((a+i), (a+j));
         permute_string(a, i+1, n);//permutes only when the characters are different
         swap((a+i), (a+j));//backtracing gives the original string
        }
         j++;
       }
   }
}
int main(){
    char str[9];
    scanf("%s",str);
    int n=strlen(str);
    qsort(str,n,sizeof(char),sort);
    int r=fact(n);
    int p= no_of_permutations(str,n,r);
    printf("%d\n",p);
    if(n<=8 && p!=40320 && p!=10080 && p!=20160){
    permute_string(str,0,n-1);
    char var[n];
    //sorting the string
    for(int i=0;i<(c-1);++i){
        for(int j=i+1;j<c;++j){
            if(strcmp(s[i],s[j])>0){
                strcpy(var,s[i]);
                strcpy(s[i],s[j]);
                strcpy(s[j],var);
            }
        }
    }
    for(int i=0;i<c;i++){
        if(strcmp(s[i],s[i+1])!=0){
            printf("%s\n",s[i]);
        }
    }
    }
    if(p==40320){
    permute(str,0,n-1);
    }
    if(p==10080 || p==20160){
        int stop = 1;
        while ( stop ){
        printf ("%s \n", str);
        int i;
        for ( i = 6; i >= 0; --i ){
        if (str[i] < str[i+1])
            break;
        }
        if ( i == -1 )
            stop= 0;
        else{  
            char s;
            s= str[i];
            int l=i+1;
            int sci=l;
            for (int i = l+1; i <= 7; i++){
            if (str[i] > s && str[i] < str[sci]){
                    sci = i;
            }
            }
            swap( &str[i], &str[sci] );
            qsort(str+ i + 1, 7 - i, sizeof(char), sort);
        }
     }
    }
    return 0;
}
