#include<stdio.h>
#include<stdlib.h>
int compare(const void *a,const void *b){
    return (*(int*)a-*(int*)b);//sorting of array using qsort
    }
int func(int[],int,int);//function to calculate the irritation using recursion and memoization concept to avoid TLE
int memo[200001];//memoization array of size 2e5 as per constrains of problem declared globally to intitialise all elements to zero
int main(){
    int t;
    int h;
    scanf("%d",&t);
    for(int k=1;k<=t;k++){
      int n;
      h=0;
      scanf("%d",&n);
      int a[n+1];
         for(int i=1;i<=n;i++){
          scanf("%d",&a[i]);
         }
         if(a[1]==1 && a[2]==2){
         for(int j=1;j<=n;j++){
         memo[j]=func(a,n,j);//calling the function for each index value
         }
         qsort(memo,n+1,sizeof(int),compare); //sorting the memoization array to get the largest value of irritation
         printf("%d\n",memo[n]);
         for(int j=1;j<=n;j++){
            memo[j]=0;//re-initializing all elements of memoization array to zero so that hey can be used for next test case

         }
         }
         else{
            int sum;
        for(int k=1;k<=n;k++){
       sum=0;
       int j=k;
       while(j<=n){
            sum=sum+a[j];//main logic of the problem
            j=a[j]+j;  
        }
        if(sum>h){
            h=sum;
        }
        }
       printf("%d\n",h);

         }
    }
    return 0;
}
int func(int a[],int n,int j ){

    if(memo[j]==0){
        if(j<=n){
        memo[j]=a[j]+func(a,n,j+a[j]);
        return memo[j];
        }
        else{
            return 0;
        }
    }
    else{
     return memo[j];
    }
}
