#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
    int n,k,p=0;
    scanf("%d %d",&n,&k);
    char str[n];
    scanf("%s",str);
    char str1[n];
    strcpy(str1,str);
    int sum=0;
    for(int i=0;i<n;i++){
        int a= str[i]-96;
        int b= abs(a-26);
        int c= abs(a-1);
        int d;
        if(b>c){
            d=b;
        }
        else{
            d=c;
        }
        sum=sum+d;
    }
    if(k>sum){
        printf("-1\n");
    }
    else{
       for(int i=0;i<n;i++){
           int a= str[i]-96;
           int c= abs(a-1);
           str[i]= 'a';
           p=p+c;
    }
    if(p==k){
        for(int v=0;v<n;v++){
            printf("%c",str[v]);
        }
      //printf("%s\n",str);
    }
    if(p<k){
       for(int i=(n-1);i>=0;i--){
          int a= str1[i]-96;
          int b= abs(a-26);
          int c= abs(a-1);
          int d;
          if(b>c){
             d=b;
          }
          else{
            d=c;
         }
         if(d==c){
            continue;
        }
        if(d==b){
           p=p-abs(a-1);
           int q=k-p;
           if(q>=d){
            p=p+d;
            str[i]='z';
           }
           else{
            int r= a+q+96;
            p=p+q;
            char w=r;
            str[i]=w;

           }
            
        }
        if(p==k){
            break;
        }
    }
    for(int v=0;v<n;v++){
            printf("%c",str[v]);
    }
    //printf("%s\n",str);
    }
    if(p>k){
        for(int i=0;i<n;i++){
        int a= str1[i]-96;
        int c= a-1;
        if(c<=k){
            k=k-c;
            char s;
            s= a-c;
            str1[i]=s+96;
            p=p+c;
        }
        else{
            c=k;
            k=k-c;
            char f;
            f= a-c;
            str1[i]=f+96;
            p=p+c;
            break;
        }
        }
        for(int v=0;v<n;v++){
            printf("%c",str1[v]);
        }
         //printf("%s\n",str1);
    }
    }
    return 0;
}
